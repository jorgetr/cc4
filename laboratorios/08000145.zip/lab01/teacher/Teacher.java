package laboratorios.lab01.teacher;

import java.io.*;
import laboratorios.lab01.Human;
import laboratorios.lab01.student.Student;
import java.util.Vector;

public class Teacher extends Human {

  private Vector<Student> studentList;

  public Teacher(String name) {
    this.nombre = name;
    studentList = new Vector<Student>();
  }

  public void addStudent(Student s) {
    this.studentList.addElement(s);
  }

  public void teach() {
    System.out.println(this.nombre + " is teaching");
    for (Student s : studentList) s.learn();
  }

  public String toString() {
    return this.nombre;
  }

}
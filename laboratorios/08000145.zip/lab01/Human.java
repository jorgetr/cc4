package laboratorios.lab01;

public abstract class Human {
	
	// add a public field, type String named 'name'
	// implement me
   	public abstract String toString();
	public String nombre;
}